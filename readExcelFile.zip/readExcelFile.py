#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
my_data = "/home/student/PRATIK/dsPExcel.xlsx"
D = pd.read_excel(my_data,"dataScienceProgram") #SPECIFY WITH SHEET  NAME.....
D.head()


# In[ ]:




