#!/usr/bin/env python
# coding: utf-8

# In[1]:


print("hello")


# In[18]:


import pandas as pd
my_path = "/home/student/PRATIK/dataScienceProgram.csv"
#for x in range(my_path):
df = pd.read_csv(my_path)
df.head(10)


# In[21]:





# In[ ]:




